%plotting histogram of different images


clc
close all
clear all

g=imread('filament.tif');
imhist(g)






