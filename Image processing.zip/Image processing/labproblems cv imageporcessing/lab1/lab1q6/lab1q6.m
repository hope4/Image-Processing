%Addition of differnt amounts of Salt and pepper noise and its removal using median filter

%Name : K Naveen Kumar
%ID   : 201451074
%Date : 16-8-2017

clc;
close all;
clear all;

input_image=imread('barbara.png');



%adding salt and pepper noise

noised_image1 = input_image; %intially taken same to get same values along the edges of the matrix
noised_image2 = input_image; %intially taken same to get same values along the edges of the matrix
noised_image3 = input_image; %intially taken same to get same values along the edges of the matrix
noised_image4 = input_image; %intially taken same to get same values along the edges of the matrix

threshold=0.005;
random_index=rand(size(input_image));
index_lessthan_threshold=find(random_index<threshold/2);
noised_image1(index_lessthan_threshold)=0;
index_greaterthan_threshold=find(random_index>=threshold/2 & random_index < threshold);
noised_image1(index_greaterthan_threshold)=1;

threshold=0.05;
random_index=rand(size(input_image));
index_lessthan_threshold=find(random_index<threshold/2);
noised_image2(index_lessthan_threshold)=0;
index_greaterthan_threshold=find(random_index>=threshold/2 & random_index < threshold);
noised_image2(index_greaterthan_threshold)=1;

threshold=0.02;
random_index=rand(size(input_image));
index_lessthan_threshold=find(random_index<threshold/2);
noised_image3(index_lessthan_threshold)=0;
index_greaterthan_threshold=find(random_index>=threshold/2 & random_index < threshold);
noised_image3(index_greaterthan_threshold)=1;

threshold=0.01;
random_index=rand(size(input_image));
index_lessthan_threshold=find(random_index<threshold/2);
noised_image4(index_lessthan_threshold)=0;
index_greaterthan_threshold=find(random_index>=threshold/2 & random_index < threshold);
noised_image4(index_greaterthan_threshold)=1;


%Applying median filter
modified_input_image1 = zeros(size(noised_image1)+2); %appending zeros along the edges
modified_input_image2 = zeros(size(noised_image2)+2); %appending zeros along the edges
modified_input_image3 = zeros(size(noised_image3)+2); %appending zeros along the edges
modified_input_image4 = zeros(size(noised_image4)+2); %appending zeros along the edges


output_image1=zeros(size(noised_image1));
output_image2=zeros(size(noised_image2));
output_image3=zeros(size(noised_image3));
output_image4=zeros(size(noised_image4));


for x=1:size(noised_image1,1)
	for y=1:size(noised_image1,2)
		modified_input_image1(x+1,y+1)=noised_image1(x,y);
		modified_input_image2(x+1,y+1)=noised_image2(x,y);
		modified_input_image3(x+1,y+1)=noised_image3(x,y);
		modified_input_image4(x+1,y+1)=noised_image4(x,y);
	end
end

for x=1:size(modified_input_image1,1)-2
	for y=1:size(modified_input_image1,2)-2
		window_of_threecrossthree1=zeros(9,1);
	    window_of_threecrossthree2=zeros(9,1);
	    window_of_threecrossthree3=zeros(9,1);
	    window_of_threecrossthree4=zeros(9,1);
		increment=1;
		for z=1:3
			for k=1:3
				window_of_threecrossthree1(increment)=modified_input_image1(x+z-1,y+k-1); %taking 9 values of 3,3 window
				window_of_threecrossthree2(increment)=modified_input_image2(x+z-1,y+k-1); %taking 9 values of 3,3 window
				window_of_threecrossthree3(increment)=modified_input_image3(x+z-1,y+k-1); %taking 9 values of 3,3 window
				window_of_threecrossthree4(increment)=modified_input_image4(x+z-1,y+k-1); %taking 9 values of 3,3 window
				increment=increment+1;
			end
		end
		med1=sort(window_of_threecrossthree1); %sorting values of the window
		med2=sort(window_of_threecrossthree2); %sorting values of the window
		med3=sort(window_of_threecrossthree3); %sorting values of the window
		med4=sort(window_of_threecrossthree4); %sorting values of the window


    	output_image1(x,y)=med1(5); %Fifth element of the sorted window is the median
    	output_image2(x,y)=med2(5); 
    	output_image3(x,y)=med3(5); 
    	output_image4(x,y)=med4(5); 

	end
end


output_image1=uint8(output_image1);
output_image2=uint8(output_image2);
output_image3=uint8(output_image3);
output_image4=uint8(output_image4);


p1=subplot(2,4,1);
imshow(noised_image1)
title(p1,"Noised image1")

p2=subplot(2,4,2);
imshow(noised_image2)
title(p2,"Noised image2")


p3=subplot(2,4,3);
imshow(noised_image3)
title(p3,"Noised image3")


p4=subplot(2,4,4);
imshow(noised_image4)
title(p4,"Noised image4")

p5=subplot(2,4,5);
imshow(output_image1)
title(p5,"removal of salt and pepper")

p6=subplot(2,4,6);
imshow(output_image2)
title(p6,"removal of salt and pepper")

p7=subplot(2,4,7);
imshow(output_image3)
title(p7,"removal of salt and pepper")

p8=subplot(2,4,8);
imshow(output_image4)
title(p8,"removal of salt and pepper")



print('saltnpepper.png','-dpng')







