%Changing gamma of a input image using imadjust() and without using imadjust()
%Name : K Naveen Kumar
%ID   : 201451074
%Date : 16-8-2017

%Imadjust : Returns an image of equal dimensions with its intensity values adjusted, usually for the purpose of increase the image constract. Obtaining negative of an image is a case in it.
%The gamma value shapes the mapping curve between the input and output elements. It defaults to 1, a linear mapping. Higher values of gamma will curve the mapping downwards and to the right, increasing the contrast in the brighter (higher) values of the input image. Lower values of gamma will curve the mapping upwards and to the left, increasing the contrast in the darker (lower) values of the input image.



clc;
close all;
clear all;


input_image = imread('barbara.png');
i1=subplot(2,4,1);
imshow(input_image)
title(i1,'Input Image')

output_imadjust1 = imadjust(input_image,[0;1],[0;1],0.1);
i3=subplot(2,4,2);
imshow(output_imadjust1)
title(i3,'Gamma value = 0.1')

output_imadjust2 = imadjust(input_image,[0;1],[0;1],0.5);
i5=subplot(2,4,3);
imshow(output_imadjust2)
title(i5,'Gamma value = 0.5')


output_imadjust3 = imadjust(input_image,[0;1],[0;1],5);
i7=subplot(2,4,4);
imshow(output_imadjust3)
title(i7,'Gamma value = 5')


i2=subplot(2,4,5);
imhist(input_image)
title(i2,'Histogram of Input Image')


i4=subplot(2,4,6);
imhist(output_imadjust1)
title(i4,'gamma = 0.1')



i6=subplot(2,4,7);
imhist(output_imadjust2)
title(i6,'gamma = 0.5')



i8=subplot(2,4,8);
imhist(output_imadjust3)
title(i8,'gamma = 5')

print('gammavariation.png','-dpng')


%*************Obtaining negative of a image witout using command..
input_image=imread('barbara.png');

double_input_image = double(input_image);

normalize_input_image = (1/255) * double_input_image;

size_normalize_input_image = size(normalize_input_image);

figure
a=subplot(2,4,1);
imshow(input_image)
title(a,'input image')

c = 0.4;
for i=1 : size_normalize_input_image(1)
	for j=1 : size_normalize_input_image(2)
		output_image(i,j) = c * log (1+normalize_input_image(i,j) ); %logarithmic transformation with c = 0.4
	end
end

denormalize_output_image = 255 * output_image;
uint_output_image = uint8(denormalize_output_image);

b1=subplot(2,4,2);
imshow(uint_output_image)
title(b1,'gamma value = 0.5')


c = 2;
for i=1 : size_normalize_input_image(1)
	for j=1 : size_normalize_input_image(2)
		output_image2(i,j) = c * log (1+normalize_input_image(i,j) ); %logarithmic transformation with c = 2
	end
end

denormalize_output_image = 255 * output_image2;
uint_output_image2 = uint8(denormalize_output_image);

b=subplot(2,4,3);
imshow(uint_output_image2)
title(b,'gamma value = 2')



c = 3;
for i=1 : size_normalize_input_image(1)
	for j=1 : size_normalize_input_image(2)
		output_image3(i,j) = c * log (1+normalize_input_image(i,j) ); %logarithmic transformation with c = 3
	end
end

denormalize_output_image = 255 * output_image3;
uint_output_image3 = uint8(denormalize_output_image);

b3=subplot(2,4,4);
imshow(uint_output_image3)
title(b3,'gamma value = 3')

i123=subplot(2,4,5);
imhist(input_image)
title(i123,'Input Image')

i10=subplot(2,4,6);
imhist(uint_output_image)
title(i10,'gamma = 0.5')

i11=subplot(2,4,7);
imhist(uint_output_image2)
title(i11,'gamma = 2')

i111=subplot(2,4,8);
imhist(uint_output_image3)
title(i111,'gamma = 3')
print('withoutusingcommand.png','-dpng')





