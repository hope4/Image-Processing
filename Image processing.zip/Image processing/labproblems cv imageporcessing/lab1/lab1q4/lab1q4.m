%implementation of Laplacian of Gaussian filter using imfilter() and by convolution

%Name : K Naveen Kumar
%ID   : 201451074
%Date : 16-8-2017

%The Laplacian is a 2-D isotropic measure of the 2nd spatial derivative of an image. 
%The Laplacian of an image highlights regions of rapid intensity change and is therefore often used for 
%edge detection . The Laplacian is often applied to an image that has 
%first been smoothed with something approximating a Gaussian smoothing filter(mean filter) in order to reduce its sensitivity to noise, 
%and hence the two variants will be described together here. The operator normally takes a single graylevel image as input 
%and produces another graylevel image as output.

clc;
close all;
clear all;

input_image=imread('barbara.png');
double_input_image=double(input_image);
size_input_image=size(input_image);

output_image_log=zeros(size_input_image(1),size_input_image(2));



%filters , mask of 3 x 3
mean_filter=[1/9 1/9 1/9;1/9 1/9 1/9;1/9 1/9 1/9];
Laplacian_filter=[-1 -1 -1;-1 8 -1;-1  -1  -1];

%first applying mean filter
output_image_log = imfilter(double_input_image,mean_filter);

%applying Laplacian filter 
output_image_log = imfilter(output_image_log,Laplacian_filter);
output_image_log_threecrossthree=uint8(output_image_log);

%filters , mask of 5 X 5
mean_filter=1/25 * ones(5,5);
Laplacian_filter=[-1 -1 -1 -1 -1;-1 -1 -1 -1 -1;-1 -1  24 -1  -1;-1 -1 -1 -1 -1;-1 -1 -1 -1 -1];

%first applying mean filter
output_image_log = imfilter(double_input_image,mean_filter);

%applying Laplacian filter 
output_image_log = imfilter(output_image_log,Laplacian_filter);
output_image_log_fivecrossfive=uint8(output_image_log);


%filters , mask of 7 X 7
mean_filter=1/49 * ones(7,7);
Laplacian_filter=[-1 -1 -1 -1 -1 -1 -1;-1 -1 -1 -1 -1 -1 -1;-1 -1 -1 -1 -1 -1 -1;-1 -1 -1 48 -1 -1 -1;-1 -1 -1 -1 -1 -1 -1;-1 -1 -1 -1 -1 -1 -1;-1 -1 -1 -1 -1 -1 -1];

%first applying mean filter
output_image_log = imfilter(double_input_image,mean_filter);

%applying Laplacian filter 
output_image_log = imfilter(output_image_log,Laplacian_filter);
output_image_log_sevencrossseven=uint8(output_image_log);



p1=subplot(2,4,1)
imshow(input_image)
title(p1,'Input image')

p2=subplot(2,4,2)
imshow(output_image_log_threecrossthree)
title(p2,'applying 3,3 log filter')


p3=subplot(2,4,3)
imshow(output_image_log_fivecrossfive)
title(p3,'applying 5,5 log filter')

p4=subplot(2,4,4)
imshow(output_image_log_sevencrossseven)
title(p4,'applying 7,7 log filter')


p5=subplot(2,4,5)
imhist(input_image)
title(p5,'input image')


p6=subplot(2,4,6)
imhist(output_image_log_threecrossthree)
title(p6,'3x3')

p7=subplot(2,4,7)
imhist(output_image_log_fivecrossfive)
title(p7,'5x5')

p8=subplot(2,4,8)
imhist(output_image_log_sevencrossseven)
title(p8,'7x7')

print('logapplicatoin.png','-dpng')



