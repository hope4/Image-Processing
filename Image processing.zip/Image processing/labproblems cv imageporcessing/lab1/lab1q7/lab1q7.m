%Addition of differnt amounts of gaussian noise and its removal using median filter

%Name : K Naveen Kumar
%ID   : 201451074
%Date : 16-8-2017

clc;
close all;
clear all;

input_image=imread('barbara.png');

input_image=im2double(input_image);

%adding salt and pepper noise

noised_image1 = input_image; %intially taken same to get same values along the edges of the matrix
noised_image2 = input_image; %intially taken same to get same values along the edges of the matrix
noised_image3 = input_image; %intially taken same to get same values along the edges of the matrix
noised_image4 = input_image; %intially taken same to get same values along the edges of the matrix


mean= 0;
variance = 0.01;
noised_image1 = noised_image1 + sqrt(variance) * randn(size(noised_image1)) + mean;


mean= 0;
variance = 0.04;
noised_image2 = noised_image2 + sqrt(variance) * randn(size(noised_image1)) + mean;


mean= 0;
variance = 0.04;
noised_image3 = noised_image3 + sqrt(variance) * randn(size(noised_image1)) + mean;


mean= 0;
variance = 0.16;
noised_image4 = noised_image4 + sqrt(variance) * randn(size(noised_image1)) + mean;


%Applying low pass filter of size 3 * 3

output_image1=zeros(size(noised_image1));
output_image2=zeros(size(noised_image2));
output_image3=zeros(size(noised_image3));
output_image4=zeros(size(noised_image4));

low_pass_filter=[1/9 1/9 1/9;1/9 1/9 1/9;1/9 1/9 1/9];

output_image1 = imfilter(noised_image1,low_pass_filter);
output_image2 = imfilter(noised_image2,low_pass_filter);
output_image3 = imfilter(noised_image3,low_pass_filter);
output_image4 = imfilter(noised_image4,low_pass_filter);

for i=1:10
	output_image1 = imfilter(output_image1,low_pass_filter);
	output_image2 = imfilter(output_image2,low_pass_filter);
	output_image3 = imfilter(output_image3,low_pass_filter);
	output_image4 = imfilter(output_image4,low_pass_filter);	
end

p1=subplot(2,4,1);
imshow(noised_image1)
title(p1,"Noised image1")

p2=subplot(2,4,2);
imshow(noised_image2)
title(p2,"Noised image2")


p3=subplot(2,4,3);
imshow(noised_image3)
title(p3,"Noised image3")


p4=subplot(2,4,4);
imshow(noised_image4)
title(p4,"Noised image4")

p5=subplot(2,4,5);
imshow(output_image1)
title(p5,"removal of gaussian noise")

p6=subplot(2,4,6);
imshow(output_image2)
title(p6,"removal of gaussian noise")

p7=subplot(2,4,7);
imshow(output_image3)
title(p7,"removal of gaussian noise")

p8=subplot(2,4,8);
imshow(output_image4)
title(p8,"removal of gaussian noise")



print('gaussian.png','-dpng')







