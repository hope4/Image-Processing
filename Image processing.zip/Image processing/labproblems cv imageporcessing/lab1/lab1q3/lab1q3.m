%implementation of low pass  , high pass filter, high boost filter using imfilter() and by convolution

%Name : K Naveen Kumar
%ID   : 201451074
%Date : 16-8-2017

%Low-pass filter : A low-pass filter is a filter that passes signals with a frequency lower than the cutoff frequency and reduce the effect of signals with frequencies higher than the cutoff frequency.

%High-pass filter : A high-pass filter is a filter that passes signals with a frequency higher than the cutoff frequency and reduce the effect of signals with frequencies lower than the cutoff frequency.

%High-boost filter : High boost filter is often desirable to emphasize high frequency components representing the image details(by means such as sharpening) without eliminating low frequency components representing the basic form of the signal.


clc;
close all;
clear all;

input_image=imread('barbara.png');
double_input_image=double(input_image);
size_input_image=size(input_image);

output_image1_lowpass=zeros(size_input_image(1),size_input_image(2));
output_image2_highpass=zeros(size_input_image(1),size_input_image(2));
output_image3_highboost=zeros(size_input_image(1),size_input_image(2));



%filters , mask of 3 x 3
low_pass_filter=[1/9 1/9 1/9;1/9 1/9 1/9;1/9 1/9 1/9];
high_pass_filter=[-1/9 -1/9 -1/9;-1/9 8/9 -1/9;-1/9 -1/9 -1/9];
high_boost_filter=[-1/9 -1/9 -1/9;-1/9 26/9 -1/9;-1/9 -1/9 -1/9];   % high boost filter with A > 1, i.e., 9 * A - 1 => 9 * 3 - 1 = 26  

%Using imfilter
fuction_output_image1_lowpass = imfilter(input_image,low_pass_filter);
fuction_output_image2_highpass = imfilter(input_image,high_pass_filter);
fuction_output_image3_highboost = imfilter(input_image,high_boost_filter);

%Using convolution with a 3 x 3 mask

for i=2:size_input_image(1)-1
	for j=2:size_input_image(2)-1
		three_cross_three_submatrix=double_input_image(i-1:i+1,j-1:j+1);   %three_cross_three_submatrix :-> 3 x 3 submatrix taken out to do convolution with mask
		convolution_sum = sum(sum(three_cross_three_submatrix.*low_pass_filter));
		output_image1_lowpass(i,j)=convolution_sum;
		convolution_sum = sum(sum(three_cross_three_submatrix.*high_pass_filter));
		output_image2_highpass(i,j)=convolution_sum;
		convolution_sum = sum(sum(three_cross_three_submatrix.*high_boost_filter));
		output_image3_highboost(i,j)=convolution_sum;
	end
end

output_image1_lowpass=uint8(output_image1_lowpass);
output_image2_highpass=uint8(output_image2_highpass);
output_image3_highboost=uint8(output_image3_highboost);


p1=subplot(3,2,1);
imshow(fuction_output_image1_lowpass)
title(p1,'Applying low pass filter using imfilter()')

p2=subplot(3,2,2);
imshow(output_image1_lowpass)
title(p2,'Applying low pass filter using convolution')

p3=subplot(3,2,3);
imshow(fuction_output_image2_highpass)
title(p3,'Applying high pass filter using imfilter()')

p4=subplot(3,2,4);
imshow(output_image2_highpass)
title(p4,'Applying high pass filter using convolution')

p5=subplot(3,2,5);
imshow(fuction_output_image3_highboost)
title(p5,'Applying high boost filter using imfilter()')


p6=subplot(3,2,6);
imshow(output_image3_highboost)
title(p6,'Applying high boost filter using convolution')

print('filterapplication.png','-dpng')