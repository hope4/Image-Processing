%Comparing imadjust(), imcomplement() to obtain negative of the image
%Name : K Naveen Kumar
%ID   : 201451074
%Date : 16-8-2017


%Imcomplement : It corresponds to the intensity of bright and dark regions being reserved. The exact operation performed is dependen on the class of the image.(doesnot give more options to change the range)

%Imadjust : Returns an image of equal dimensions with its intensity values adjusted, usually for the purpose of increase the image constract. Obtaining negative of an image is a case in it. where the range is inverted it outputs a negative image. Imcomplement() is a part of Imadjust()

clc;
close all;
clear all;


input_image = imread('barbara.png');


output_imadjust = imadjust(input_image,[0.5;0.9],[0;1]);
i1=subplot(3,2,1);
imshow(output_imadjust)
title(i1,'Increasing the brighness using imadjust()')

output_imcomplement = imcomplement(input_image);
i4=subplot(3,2,2);
imshow(output_imcomplement)
title(i4,'Imcomplement() command applied on input image')

output_imadjust = imadjust (input_image, stretchlim (input_image, 0.5), [0; 1]);
i2=subplot(3,2,3);
imshow(output_imadjust)
title(i2,'contrast streching using imadjust()')

output_imcomplement = imcomplement(input_image);
i5=subplot(3,2,4);
imshow(output_imcomplement)
title(i5,'Imcomplement() command applied on input image')

output_imadjust = imadjust(input_image,[0;1],[1;0]);
i3=subplot(3,2,5);
imshow(output_imadjust)
title(i3,'negative using imadjust()')

output_imcomplement = imcomplement(input_image);
i6=subplot(3,2,6);
imshow(output_imcomplement)
title(i6,'Imcomplement() command applied on input image')
print('comparision.png','-dpng')



%**********************Obtaining negative of a image witout using command


input_image=imread('barbara.png');

double_input_image = double(input_image);

normalize_input_image = (1/255) * double_input_image;

size_normalize_input_image = size(normalize_input_image);

for i=1 : size_normalize_input_image(1)
	for j=1 : size_normalize_input_image(2)
		output_image(i,j) = (-1)*normalize_input_image(i,j) + 1; %linear transformation ,(y = mx+c) with slope -1 and intersecpt +1 to obtain negative image
	end
end

denormalize_output_image = 255 * output_image;

uint_output_image = uint8(denormalize_output_image);

figure
a=subplot(1,2,1);
imshow(input_image)
title(a,'input image')

b=subplot(1,2,2);
imshow(uint_output_image)
title(b,'Negative of input image without using imadjust() or imcomplement()')
print('withoutusingcommand.png','-dpng')






