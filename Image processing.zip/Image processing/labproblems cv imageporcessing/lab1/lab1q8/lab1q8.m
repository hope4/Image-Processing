%repeatedly applying low_pass_filter on an image

%Name : K Naveen Kumar
%ID   : 201451074
%Date : 16-8-2017

%Low-pass filter : A low-pass filter is a filter that passes signals with a frequency lower than the cutoff frequency and reduce the effect of signals with frequencies higher than the cutoff frequency.



clc;
close all;
clear all;

input_image=imread('barbara.png');
double_input_image=double(input_image);
size_input_image=size(input_image);

no_of_iterations = 10000;

output_image1_lowpass=zeros(size_input_image(1),size_input_image(2));

%filters , mask of 3 x 3
low_pass_filter=[1/9 1/9 1/9;1/9 1/9 1/9;1/9 1/9 1/9];


%Using imfilter
fuction_output_image1_lowpass = imfilter(input_image,low_pass_filter);

for i=1:no_of_iterations
	 fuction_output_image1_lowpass = imfilter(fuction_output_image1_lowpass,low_pass_filter);
end



p1=subplot(1,2,1);
imshow(input_image)
title(p1,'input image')

p2=subplot(1,2,2);
imshow(fuction_output_image1_lowpass)
title(p2,'Applying low pass filter using imfilter() for 10000 times')


print('multipletimesfilterapplication.png','-dpng')