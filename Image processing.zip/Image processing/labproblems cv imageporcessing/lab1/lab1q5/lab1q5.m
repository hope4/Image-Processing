%implementation of Laplacian of Gaussian filter using imfilter() and by convolution

%Name : K Naveen Kumar
%ID   : 201451074
%Date : 16-8-2017

%The Laplacian is a 2-D isotropic measure of the 2nd spatial derivative of an image. 
%The Laplacian of an image highlights regions of rapid intensity change and is therefore often used for 
%edge detection . The Laplacian is often applied to an image that has 
%first been smoothed with something approximating a Gaussian smoothing filter(mean filter) in order to reduce its sensitivity to noise, 
%and hence the two variants will be described together here. The operator normally takes a single graylevel image as input 
%and produces another graylevel image as output.


%Gaussian followed by Laplacian gives a very sharpe edges without any noise as we increase the mask size
%highpass filter is a 1 D dervative , it reduces the global contrast of an image , as we are eliminating low pass components from image

clc;
close all;
clear all;

input_image=imread('barbara.png');
double_input_image=double(input_image);
size_input_image=size(input_image);

output_image_log=zeros(size_input_image(1),size_input_image(2));
output_image_highpass=zeros(size_input_image(1),size_input_image(2));



%filters , mask of 3 x 3
mean_filter=[1/9 1/9 1/9;1/9 1/9 1/9;1/9 1/9 1/9];
Laplacian_filter=[-1 -1 -1;-1 8 -1;-1  -1  -1];
high_pass_filter=1/9 * Laplacian_filter;

%first applying mean filter
output_image_log = imfilter(double_input_image,mean_filter);

%applying Laplacian filter 
output_image_log = imfilter(output_image_log,Laplacian_filter);
output_image_highpass=imfilter(input_image,high_pass_filter);
output_image_log_threecrossthree=uint8(output_image_log);
output_image_highpass_threecrossthree=output_image_highpass;

%filters , mask of 5 X 5
mean_filter=1/25 * ones(5,5);
Laplacian_filter=[-1 -1 -1 -1 -1;-1 -1 -1 -1 -1;-1 -1  24 -1  -1;-1 -1 -1 -1 -1;-1 -1 -1 -1 -1];
high_pass_filter=1/25 * Laplacian_filter;


%first applying mean filter
output_image_log = imfilter(double_input_image,mean_filter);

%applying Laplacian filter 
output_image_log = imfilter(output_image_log,Laplacian_filter);
output_image_highpass=imfilter(input_image,high_pass_filter);
output_image_log_fivecrossfive=uint8(output_image_log);
output_image_highpass_fivecrossfive=output_image_highpass;



%filters , mask of 7 X 7
mean_filter=1/49 * ones(7,7);
Laplacian_filter=[-1 -1 -1 -1 -1 -1 -1;-1 -1 -1 -1 -1 -1 -1;-1 -1 -1 -1 -1 -1 -1;-1 -1 -1 48 -1 -1 -1;-1 -1 -1 -1 -1 -1 -1;-1 -1 -1 -1 -1 -1 -1;-1 -1 -1 -1 -1 -1 -1];
high_pass_filter=1/49 * Laplacian_filter;


%first applying mean filter
output_image_log = imfilter(double_input_image,mean_filter);


%applying Laplacian filter 
output_image_log = imfilter(output_image_log,Laplacian_filter);
output_image_highpass=imfilter(input_image,high_pass_filter);
output_image_log_sevencrossseven=uint8(output_image_log);
output_image_highpass_fivecrossfive=output_image_highpass;

p1=subplot(3,2,1)
imshow(output_image_log_threecrossthree)
title(p1,'3x3 log')

p2=subplot(3,2,2)
imshow(output_image_highpass)
title(p2,'3x3 highpass')

p3=subplot(3,2,3)
imshow(output_image_log_fivecrossfive)
title(p3,'5x5 log')

p4=subplot(3,2,4)
imshow(output_image_highpass_fivecrossfive)
title(p4,'5x5 highpass')


p5=subplot(3,2,5)
imshow(output_image_log_sevencrossseven)
title(p5,'7x7 log')


p6=subplot(3,2,6)
imshow(output_image_highpass_fivecrossfive)
title(p6,'7x7 highpass')

print("loghighpass.png",'-dpng')





