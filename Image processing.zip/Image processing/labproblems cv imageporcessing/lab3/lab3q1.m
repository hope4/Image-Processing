%translation , rotation of the image

clc
close all
clear all


input_image=imread('barbara.png');
size_input_image=size(input_image);

output_image=input_image;


identity_matrix = [1 0;0 1];
theta = pi / 2;

rotation_matrix = [cos(theta) -sin(theta);sin(theta) cos(theta)];
rotation_matrix = round(rotation_matrix);
translation_vector = [100 200];

for i=1:size_input_image(1)
	for j=1:size_input_image(2)
		temp = identity_matrix * [i j]' + translation_vector';
		output_image(temp(1),temp(2)) = input_image(i,j);
	end
end

p1=subplot(3,2,1)
imshow(output_image)
title(p1,'Translation')

output_image = zeros(size_input_image(1),size_input_image(2));
output_image=input_image;
for i=1:size_input_image(1)
	for j=1:size_input_image(2)
		temp = abs(rotation_matrix * [i j]');
		output_image(temp(1),temp(2)) = input_image(i,j);
	end
end


p2=subplot(3,2,2)
imshow(output_image)
title(p2,'Rotation')


s = 1;
output_image = zeros(size_input_image(1),size_input_image(2));
output_image=input_image;
for i=1:size_input_image(1)
	for j=1:size_input_image(2)
		temp = s * abs(rotation_matrix * [i j]') + translation_vector' ;
		output_image(temp(1),temp(2)) = input_image(i,j);
	end
end


p3=subplot(3,2,3)
imshow(output_image)
title(p3,'Rotation and Translation')

%****************Reflection over y axis
output_image = zeros(size_input_image(1),size_input_image(2));
output_image=input_image;
for i=1:size_input_image(1)
	for j=1:size_input_image(2)
		temp=abs([i j]' - [0 size_input_image(2)+1]');
		output_image(temp(1),temp(2)) = input_image(i,j);
	end
end

p4=subplot(3,2,4)
imshow(output_image)
title(p4,'Reflection over y axis')

%****************Reflection over x axis

output_image = zeros(size_input_image(1),size_input_image(2));
output_image=input_image;
for i=1:size_input_image(1)
	for j=1:size_input_image(2)
		temp=abs([i j]' - [size_input_image(1)+1 0]');
		output_image(temp(1),temp(2)) = input_image(i,j);
	end
end

p5=subplot(3,2,5)
imshow(output_image)
title(p5,'Reflection over x axis')

%***************AFFINE

affine_matrix = [1 1;1 1];
output_image = zeros(size_input_image(1),size_input_image(2));
output_image=input_image;
translation_vector = [100 200];

for i=1:size_input_image(1)
	for j=1:size_input_image(2)
		temp = affine_matrix * [i j]' + translation_vector';
		output_image(temp(1),temp(2)) = input_image(i,j);
	end
end

p6=subplot(3,2,6)
imshow(output_image)
title(p6,'Affine')
print('geometrictransformations.png','-dpng')