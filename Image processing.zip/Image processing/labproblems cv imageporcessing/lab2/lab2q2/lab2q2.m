%stastical scaling, inverse contrast ratio

%Name : K Naveen Kumar
%ID   : 201451074
%Date : 23-8-2017

%Low-pass filter : A low-pass filter is a filter that passes signals with a frequency lower than the cutoff frequency and reduce the effect of signals with frequencies higher than the cutoff frequency.

clc;
close all;
clear all;

input_image  = imread('barbara.png');
size_input_image = size(input_image);

input_image = imcrop(input_image,[3 3 size_input_image(1)-3 size_input_image(2)-3]);
size_input_image = size(input_image);
double_input_image = double(input_image);

local_mean = zeros(1,size_input_image(1)/3 * size_input_image(1)/3);
local_variance = zeros(1,size_input_image(1)/3 * size_input_image(1)/3);

%********************************************************************
Inverse_contrast_ratio = zeros (size_input_image(1),size_input_image(2));

j=1;
counter = 1;
while(j < 509)
	i=1;
	while(i < 509)
		window = input_image(j:j+2,i:i+2);
		mu = mean(mean(window));
		sig = var(var(window));
		local_mean(counter) = mu;
		local_variance (counter)=sig;
		i=i+3;
		counter = counter + 1;
	end
	j=j+3;
end

vm_n=ceil(local_mean ./ local_variance);

j=1;
counter = 1;
while(j < 509)
	i=1;
	while(i < 509)
		window = input_image(j:j+2,i:i+2);
		Inverse_contrast_ratio(j:j+2,i:i+2) = window ./ vm_n(counter);
		i=i+3;
		counter = counter + 1;
	end
	j=j+3;
end

p1=subplot(1,2,1)
imagesc(Inverse_contrast_ratio), colormap(gray)
title(p1,'Inverse contrast ratio -> low contrast edges are enhanced')


%******************statistical scaling
statistical_scaling = zeros (size_input_image(1),size_input_image(2));


global_var = var(var(input_image));

vsm_n = input_image ./ global_var;

statistical_scaling = input_image ./ vsm_n;

p2=subplot(1,2,2)
imagesc(statistical_scaling), colormap(gray)
title(p2,'statistical scaling')

print('icr_stscaling.png','-dpng')

