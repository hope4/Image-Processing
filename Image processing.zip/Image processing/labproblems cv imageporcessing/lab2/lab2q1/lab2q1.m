%Noise deblurring

%Name : K Naveen Kumar
%ID   : 201451074
%Date : 23-8-2017


clc;
close all;
clear all;

input_image=imread('barbara.png');
size_input_image=size(input_image);


%blur matrix, disk -> circular filter
blur_matrix = [.1111 .1112 .1113; .1110 .1109 .1111; .1112 .1114 .1111];
%blur_matrix_noise = blur_matrix + [.0001 0 0; 0 0 0; 0 0 0];

%blur_matrix=fspecial("disk");

blurred_image = conv2(input_image,blur_matrix);

pseudo_inverse_blur_matrix= inv(blur_matrix);

output_image=conv2(blurred_image,pseudo_inverse_blur_matrix);

output_image1=imcrop(output_image,[5 5 size_input_image(1)-1 size_input_image(1)-1]);


p1=subplot(1,5,1);
imshow(input_image)
title(p1,"Input image")

p2=subplot(1,5,2);
imshow(blurred_image,[])
title(p2,'Blurred image')


p3=subplot(1,5,3);
imshow(output_image1,[])
title(p3,'output after deblurring')

%*************************************************


%adding slight gaussian noise to blur matrix with mean = 0,variance = 0.001

%noised_blur_matrix=imnoise(blur_matrix,"gaussian",0,0.001);
blur_matrix_noise = blur_matrix + [.0001 0 0; 0 0 0; 0 0 0];
pseudo_inverse_noised_blur_matrix= inv(blur_matrix_noise);

output_image=conv2(blurred_image,pseudo_inverse_noised_blur_matrix);

p4=subplot(1,5,4);
imshow(output_image,[])
title(p4,'deblurring with slight noise in blur matrix')

%adding slight gaussian noise to blurred image with mean = 0,variance = 0.001
noised_blurred_image=imnoise(blurred_image,"gaussian",0,0.001);
output_image=conv2(noised_blurred_image,pseudo_inverse_blur_matrix);

p5=subplot(1,5,5);
imshow(output_image,[])
title(p5,'deblurring with slight noise in blurred image')
print('dnoising.png','-dpng')


rmse = zeros(size_input_image(1),size_input_image(1));
for i=1:size_input_image(1)
	for j=1:size_input_image(2)
		rmse(i,j) = sqrt((input_image(i,j) - output_image1(i,j))^2);
	end
end
mu= mean(mean(rmse))
sig= var(var(rmse))

figure
imagesc(rmse), colormap(gray)
title('RMSE Map')
print('rmsemap.png','-dpng')