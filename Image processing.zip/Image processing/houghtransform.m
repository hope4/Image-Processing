%Hough transform

clc;
close all;
clear all;


Input1=ones(5,5);

Input1=0*Input1;

for i=1:5
	Input1(i,i)=255;
end

imshow(Input1)


[iheight,iwidth]=size(Input1);

distmax=round(sqrt(iheight^2+iwidth^2));

theta = -90:1:89;

rho = -distmax:1:distmax;

H=zeros(length(rho),length(theta)); % Allocate accumulator array

for ix=1:iwidth
	for iy=1:iheight
		if Input1(iy,ix) ~= 0

			for itheta = 1:length(theta)
				t=theta(itheta)*pi/180;

				dist=ix*cos(t)+iy*sin(t);

				[d,iRho]=min(abs(rho - dist));

				if d<=1
				
					H(iRho,itheta) = H(iRho,itheta) + 1;
				end
			end
		end
	end
end
