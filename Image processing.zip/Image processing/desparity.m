#desparity map

clc
close all
clear all


img1 = imread('1.png');
img2 = imread('2.png');


#i1 = imresize(i,[256 256]);
#j1=  imresize(j,[256 256]);

#imshow(i1,[])
#figure
#imshow(j1,[])

corelation=ones(256*256,1);
corelation= 1000*corelation;
coordinates = zeros(256*256,2);
count = 0;
for i = 1 : 256
        for j = 1 : 256
                temp1 = img1(i,j);
                count = count + 1;
                        for l = 1:256
                                temp2= img2(i,l);
                                temp = abs(temp1-temp2);
                                if(temp < corelation(count))
                                        corelation(count) = temp;
                                        coordinates(i,1)= i;
                                        coordinates(i,2)= l;
                                end
                        end
   
                
        end
end
