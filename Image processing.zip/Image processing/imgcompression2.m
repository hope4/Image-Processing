%image compression

clc
close all
clear all

input_image = imread('barbara.png');
%input_image = input_image(1 : 50,1:50);

size_of_image = size(input_image);

output_image1 = zeros(size_of_image(1),size_of_image(2));
output_image2 = zeros(size_of_image(1),size_of_image(2));
output_image3 = zeros(size_of_image(1),size_of_image(2));
output_image4 = zeros(size_of_image(1),size_of_image(2));
output_image5 = zeros(size_of_image(1),size_of_image(2));
output_image6 = zeros(size_of_image(1),size_of_image(2));
output_image7 = zeros(size_of_image(1),size_of_image(2));
output_image8 = zeros(size_of_image(1),size_of_image(2));

output_image11 = zeros(size_of_image(1),size_of_image(2));
output_image21 = zeros(size_of_image(1),size_of_image(2));
output_image31 = zeros(size_of_image(1),size_of_image(2));
output_image41 = zeros(size_of_image(1),size_of_image(2));
output_image51 = zeros(size_of_image(1),size_of_image(2));
output_image61 = zeros(size_of_image(1),size_of_image(2));
output_image71 = zeros(size_of_image(1),size_of_image(2));
output_image81 = zeros(size_of_image(1),size_of_image(2));

for i = 1 : size_of_image(1)
	for  j = 2 : size_of_image(2)
		dec = input_image(i,j);
		a = dec2bin(dec);	
		binary = zeros(1,8);
		m = 8-length(a)+1;
		for k =  m : 8
			binary(k) = a(k - 8 + length(a)) - 48;
		end
		output_image81(i,j) =  binary(1);
		output_image71(i,j) =  binary(2);
		output_image61(i,j) =  binary(3);
		output_image51(i,j) =  binary(4);
		output_image41(i,j) =  binary(5);
		output_image31(i,j) =  binary(6);
		output_image21(i,j) =  binary(7);
		output_image11(i,j) =  binary(8);

		output_image8(i,j) =  (2^7)* binary(1);
		output_image7(i,j) =  (2^6)* binary(2);
		output_image6(i,j) =  (2^5)* binary(3);
		output_image5(i,j) =  (2^4)* binary(4);
		output_image4(i,j) =  (2^3)* binary(5);
		output_image3(i,j) =  (2^2)* binary(6);
		output_image2(i,j) =  (2^1)* binary(7);
		output_image1(i,j) =  (2^0)* binary(8);
	end
end

figure
imshow(input_image,[]);
print('input image.png','-dpng')
figure
imshow(output_image1,[]);
print('image1.png','-dpng')
figure
imshow(output_image2,[]);
print('image2.png','-dpng')
figure
imshow(output_image3,[]);
print('image3.png','-dpng')
figure
imshow(output_image4,[]);
print('image4.png','-dpng')
figure
imshow(output_image5,[]);
print('image5.png','-dpng')
figure
imshow(output_image6,[]);
print('image6.png','-dpng')
figure
imshow(output_image7,[]);
print('image7.png','-dpng')
figure
imshow(output_image8,[]);
print('image8.png','-dpng')

%compressing........
compressed_image = zeros(size_of_image(1),size_of_image(2));
compress = zeros(1,4);
for i = 1 : size_of_image(1)
	for j = 1:size_of_image(2)
		compress(1) = output_image81(i,j);
		compress(2) = output_image71(i,j);
		compress(3) = output_image61(i,j);
		compress(4) = output_image51(i,j);
		binary = num2str(compress);
		decimal = bin2dec(binary);
		compressed_image(i,j) = decimal;
	end
end

figure
imshow(compressed_image,[])
print('4bitcompressedimage.png','-dpng')
