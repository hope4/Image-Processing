%shape from shading


clc
close all
clear all


n = input('Give n-> ')
input_matrix = zeros(n,n);
r=n/2;

for i = 1 : n
	for j = 1 : n
		if ((n/2 - i )^2 + (n/2 - j )^2) > r^2
			input_matrix(i,j) = 0;
		else
			input_matrix(i,j) = sqrt( (r^2 - ((n/2 - i )^2 + (n/2 - j )^2)) / r^2 );
		end
	end
end

input_matrix = real(input_matrix);
imshow(input_matrix)
print('sphere.png','-dpng')

%************calcuating p , q matrices

p1 = ones(n,n);
q1 = ones(n,n);
p11 = ones(n,n);
q11 = ones(n,n);
R  = ones(n,n);
dR_upon_dp  = ones(n,n);
dR_upon_dq  = ones(n,n);

lambda = 400;

for i = 2 : n-1
	for j = 2 : n-1
		p11(i,j) = ( p1(i+1,j)+p1(i-1,j)+p1(i,j+1)+p1(i,j-1) ) / 4;
		q11(i,j) = ( q1(i+1,j)+q1(i-1,j)+q1(i,j+1)+q1(i,j-1) ) / 4;

		R(i,j)   =  1 / (sqrt (p1(i,j)^2 + q1(i,j)^2 + 1));

		dR_upon_dp(i,j) = - p1(i,j) / ( (p1(i,j)^2 + q1(i,j)^2 + 1) ^ (3/2) );

		dR_upon_dq(i,j) = - q1(i,j) / ( (p1(i,j)^2 + q1(i,j)^2 + 1) ^ (3/2) );

	end
end

p2 = p11 + (lambda/(4)) * (input_matrix - R) .* (dR_upon_dp);
q2 = q11 + (lambda/(4)) * (input_matrix - R) .* (dR_upon_dq);

number_of_iterations = 0 ;

while (number_of_iterations <200)

		p1 = p2;
		q1 = q2;

		for i = 2 : n-1
			for j = 2 : n-1
				p11(i,j) = ( p1(i+1,j)+p1(i-1,j)+p1(i,j+1)+p1(i,j-1) ) / 4;
				q11(i,j) = ( q1(i+1,j)+q1(i-1,j)+q1(i,j+1)+q1(i,j-1) ) / 4;

				R(i,j)   =  1 / (sqrt (p1(i,j)^2 + q1(i,j)^2 + 1));

				dR_upon_dp(i,j) = - p1(i,j) / ( (p1(i,j)^2 + q1(i,j)^2 + 1) ^ (3/2) );
				dR_upon_dq(i,j) = - q1(i,j) / ( (p1(i,j)^2 + q1(i,j)^2 + 1) ^ (3/2) );

			end
		end

		p2 = p11 + (lambda/(4)) * (input_matrix - R) .* (dR_upon_dp);
		q2 = q11 + (lambda/(4)) * (input_matrix - R) .* (dR_upon_dq);

		number_of_iterations = number_of_iterations + 1;
end

%************calcuating z matrices

z1 = ones(n,n);
z11 = ones(n,n);
z2 =ones(n,n);

for i = 2 : n-1
	for j = 2 : n-1
		z11(i,j) =  z1(i+1,j)+z1(i-1,j)+z1(i,j+1)+z1(i,j-1);

		z2(i,j) = (z11(i,j) + p2(i,j) + p2(i-1,j) + q2(i,j) + q2(i,j-1) ) / 4;

	end
end

number_of_iterations = 0 ;

while (number_of_iterations <200)
		z1 = z2;

		for i = 2 : n-1
			for j = 2 : n-1
				z11(i,j) =  z1(i+1,j)+z1(i-1,j)+z1(i,j+1)+z1(i,j-1);

				z2(i,j)= (z11(i,j) + (p2(i,j) - p2(i-1,j) + q2(i,j) - q2(i,j-1))) / 4;

			end
		end

		number_of_iterations = number_of_iterations + 1;
end

figure
%z=p2+q2;
imshow(p2,[])
title('Gradient along x axis')

figure
imshow(q2,[])
title('Gradient along y axis')

figure
imshow(z2,[])
title('Depth Map')

%print('Depthmap.png','-dpng')


%**************adding noise to the image

input_matrix = imnoise(input_matrix,"gaussian",1,0.01);

figure
imshow(input_matrix,[])


p1 = ones(n,n);
q1 = ones(n,n);
p11 = ones(n,n);
q11 = ones(n,n);
R  = ones(n,n);
dR_upon_dp  = ones(n,n);
dR_upon_dq  = ones(n,n);

lambda = 400;

for i = 2 : n-1
	for j = 2 : n-1
		p11(i,j) = ( p1(i+1,j)+p1(i-1,j)+p1(i,j+1)+p1(i,j-1) ) / 4;
		q11(i,j) = ( q1(i+1,j)+q1(i-1,j)+q1(i,j+1)+q1(i,j-1) ) / 4;

		R(i,j)   =  1 / (sqrt (p1(i,j)^2 + q1(i,j)^2 + 1));

		dR_upon_dp(i,j) = - p1(i,j) / ( (p1(i,j)^2 + q1(i,j)^2 + 1) ^ (3/2) );

		dR_upon_dq(i,j) = - q1(i,j) / ( (p1(i,j)^2 + q1(i,j)^2 + 1) ^ (3/2) );

	end
end

p2 = p11 + (lambda/(4)) * (input_matrix - R) .* (dR_upon_dp);
q2 = q11 + (lambda/(4)) * (input_matrix - R) .* (dR_upon_dq);

number_of_iterations = 0 ;

while (number_of_iterations <200)

		p1 = p2;
		q1 = q2;

		for i = 2 : n-1
			for j = 2 : n-1
				p11(i,j) = ( p1(i+1,j)+p1(i-1,j)+p1(i,j+1)+p1(i,j-1) ) / 4;
				q11(i,j) = ( q1(i+1,j)+q1(i-1,j)+q1(i,j+1)+q1(i,j-1) ) / 4;

				R(i,j)   =  1 / (sqrt (p1(i,j)^2 + q1(i,j)^2 + 1));

				dR_upon_dp(i,j) = - p1(i,j) / ( (p1(i,j)^2 + q1(i,j)^2 + 1) ^ (3/2) );
				dR_upon_dq(i,j) = - q1(i,j) / ( (p1(i,j)^2 + q1(i,j)^2 + 1) ^ (3/2) );

			end
		end

		p2 = p11 + (lambda/(4)) * (input_matrix - R) .* (dR_upon_dp);
		q2 = q11 + (lambda/(4)) * (input_matrix - R) .* (dR_upon_dq);

		number_of_iterations = number_of_iterations + 1;
end

%************calcuating z matrices

z1 = ones(n,n);
z11 = ones(n,n);
z2 =ones(n,n);

for i = 2 : n-1
	for j = 2 : n-1
		z11(i,j) =  z1(i+1,j)+z1(i-1,j)+z1(i,j+1)+z1(i,j-1);

		z2(i,j) = (z11(i,j) + p2(i,j) + p2(i-1,j) + q2(i,j) + q2(i,j-1) ) / 4;

	end
end

number_of_iterations = 0 ;

while (number_of_iterations <200)
		z1 = z2;

		for i = 2 : n-1
			for j = 2 : n-1
				z11(i,j) =  z1(i+1,j)+z1(i-1,j)+z1(i,j+1)+z1(i,j-1);

				z2(i,j)= (z11(i,j) + (p2(i,j) - p2(i-1,j) + q2(i,j) - q2(i,j-1))) / 4;

			end
		end

		number_of_iterations = number_of_iterations + 1;
end


figure
%z=p2+q2;
imshow(p2,[])
title('Gradient along x axis')

figure
imshow(q2,[])
title('Gradient along y axis')

figure
imshow(z2,[])
title('Depth Map')